import React, { useRef, useEffect, useState } from 'react';
import { Socket } from 'socket.io-client';

interface CanvasProps {
  isDrawing: boolean;
  onDraw: (data: { x: number; y: number; drawing: boolean }) => void;
  socket: Socket | null;
}

export const Canvas: React.FC<CanvasProps> = ({ isDrawing, onDraw, socket }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [drawing, setDrawing] = useState(false);
  const [context, setContext] = useState<CanvasRenderingContext2D | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Make canvas responsive
    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      
      // Use clientWidth for better mobile support
      const width = parent.clientWidth;
      // Maintain aspect ratio while being responsive
      const height = Math.min(width * 0.75, window.innerHeight * 0.6);
      
      // Set both CSS and canvas dimensions for proper scaling
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      
      // Set actual canvas dimensions with device pixel ratio for sharp rendering
      const scale = window.devicePixelRatio;
      canvas.width = width * scale;
      canvas.height = height * scale;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Scale context to match device pixel ratio
        ctx.scale(scale, scale);
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        setContext(ctx);
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Listen for draw events from other players
    if (socket) {
      socket.on('draw', (data: { x: number; y: number; drawing: boolean }) => {
        if (!isDrawing) {
          drawOnCanvas(data.x, data.y, data.drawing);
        }
      });

      socket.on('clearCanvas', () => {
        clearCanvas();
      });
    }

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (socket) {
        socket.off('draw');
        socket.off('clearCanvas');
      }
    };
  }, [socket, isDrawing]);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx && canvas) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const getCanvasCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    const scale = canvas.width / rect.width;
    
    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    return {
      x: (clientX - rect.left) * scale,
      y: (clientY - rect.top) * scale
    };
  };

  const drawOnCanvas = (x: number, y: number, isDrawing: boolean) => {
    if (!context) return;

    if (!isDrawing) {
      context.beginPath();
      context.moveTo(x, y);
    } else {
      context.lineTo(x, y);
      context.stroke();
    }
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    e.preventDefault();
    
    const coords = getCanvasCoordinates(e);
    if (!coords) return;
    
    setDrawing(true);
    context?.beginPath();
    context?.moveTo(coords.x, coords.y);
    onDraw({ x: coords.x, y: coords.y, drawing: false });
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!drawing || !isDrawing) return;
    e.preventDefault();
    
    const coords = getCanvasCoordinates(e);
    if (!coords || !context) return;
    
    context.lineTo(coords.x, coords.y);
    context.stroke();
    onDraw({ x: coords.x, y: coords.y, drawing: true });
  };

  const stopDrawing = () => {
    if (context) {
      context.closePath();
    }
    setDrawing(false);
  };

  return (
    <canvas
      ref={canvasRef}
      className="border border-gray-300 bg-white rounded-lg shadow-md cursor-crosshair touch-none w-full"
      onMouseDown={startDrawing}
      onMouseMove={draw}
      onMouseUp={stopDrawing}
      onMouseOut={stopDrawing}
      onTouchStart={startDrawing}
      onTouchMove={draw}
      onTouchEnd={stopDrawing}
    />
  );
};