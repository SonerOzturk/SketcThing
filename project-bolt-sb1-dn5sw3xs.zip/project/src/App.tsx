import React, { useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { Login } from './components/Login';
import { Canvas } from './components/Canvas';
import { PlayerList } from './components/PlayerList';
import { useGameStore } from './store/gameStore';
import { Pencil } from 'lucide-react';

function App() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [username, setUsername] = useState<string | null>(null);
  const { 
    players,
    currentWord,
    isGameStarted,
    timeLeft,
    resetGame,
    addPlayer,
    removePlayer,
    updateScore,
    setCurrentWord,
    setIsGameStarted,
    setTimeLeft,
    setDrawingPlayer,
    clearPlayers
  } = useGameStore();

  const isDrawing = players.find(p => p.id === socket?.id)?.isDrawing || false;

  useEffect(() => {
    if (username) {
      // Connect to the game server using environment variable
      const serverUrl = import.meta.env.VITE_SERVER_URL || 'http://localhost:3000';
      const newSocket = io(serverUrl, {
        transports: ['websocket'],
        upgrade: false
      });

      // Handle connection
      newSocket.on('connect', () => {
        console.log('Connected to server with ID:', newSocket.id);
        newSocket.emit('join', { username });
      });

      // Clear existing players when connecting
      clearPlayers();

      // Handle player updates
      newSocket.on('players', (serverPlayers) => {
        console.log('Received players:', serverPlayers);
        clearPlayers(); // Clear existing players before adding new ones
        serverPlayers.forEach(addPlayer);
      });

      newSocket.on('playerJoined', (player) => {
        console.log('Player joined:', player);
        addPlayer(player);
      });

      newSocket.on('playerLeft', (playerId) => {
        console.log('Player left:', playerId);
        removePlayer(playerId);
      });

      // Handle game state updates
      newSocket.on('gameStarted', ({ word, drawingPlayerId }) => {
        console.log('Game started:', { word, drawingPlayerId });
        setIsGameStarted(true);
        setCurrentWord(word);
        setDrawingPlayer(drawingPlayerId);
      });

      newSocket.on('timeUpdate', (time) => {
        setTimeLeft(time);
      });

      newSocket.on('correctGuess', ({ playerId, score }) => {
        console.log('Correct guess:', { playerId, score });
        updateScore(playerId, score);
      });

      newSocket.on('roundEnd', () => {
        setCurrentWord(null);
        setIsGameStarted(false);
      });

      setSocket(newSocket);

      // Cleanup on unmount
      return () => {
        newSocket.close();
        clearPlayers();
      };
    }
  }, [username]);

  const handleDraw = (data: { x: number; y: number; drawing: boolean }) => {
    if (socket && isDrawing) {
      socket.emit('draw', data);
    }
  };

  const handleGuess = (guess: string) => {
    if (socket && !isDrawing && isGameStarted) {
      socket.emit('guess', { guess });
    }
  };

  if (!username) {
    return <Login onLogin={setUsername} />;
  }

  return (
    <div className="min-h-screen bg-gray-100 p-2 sm:p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col lg:grid lg:grid-cols-[1fr_300px] gap-4">
          <div className="space-y-4 order-2 lg:order-1">
            <div className="bg-white p-2 sm:p-4 rounded-lg shadow-md">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-2">
                <div className="flex items-center gap-2">
                  <Pencil className="w-5 h-5" />
                  <h2 className="text-base sm:text-lg font-bold">
                    {isDrawing ? `Çizilecek Kelime: ${currentWord}` : 'Kelimeyi Tahmin Et!'}
                  </h2>
                </div>
                <div className="text-sm sm:text-base font-semibold">
                  {isGameStarted ? (
                    `Kalan Süre: ${timeLeft} saniye`
                  ) : (
                    players.length < 2 ? 
                    'Oyunun başlaması için en az 2 oyuncu gerekli' :
                    'Oyun başlamak üzere...'
                  )}
                </div>
              </div>
              <Canvas isDrawing={isDrawing} onDraw={handleDraw} socket={socket} />
              {!isDrawing && isGameStarted && (
                <div className="mt-4">
                  <input
                    type="text"
                    placeholder="Tahmininizi yazın..."
                    className="w-full p-2 border rounded"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        handleGuess(e.currentTarget.value);
                        e.currentTarget.value = '';
                      }
                    }}
                  />
                </div>
              )}
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <PlayerList />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;