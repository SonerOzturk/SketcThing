import React from 'react';
import { useGameStore } from '../store/gameStore';
import { User } from 'lucide-react';

export const PlayerList: React.FC = () => {
  const players = useGameStore((state) => state.players);

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-xl font-bold mb-4">Oyuncular ({players.length})</h2>
      <div className="space-y-2">
        {players.length === 0 ? (
          <p className="text-gray-500 text-center">Henüz oyuncu yok</p>
        ) : (
          players.map((player) => (
            <div
              key={player.id}
              className={`flex items-center justify-between p-2 rounded ${
                player.isDrawing ? 'bg-blue-100' : 'bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-2">
                <User className="w-5 h-5" />
                <span>{player.username}</span>
              </div>
              <span className="font-bold">{player.score} puan</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};