import { create } from 'zustand';
import { GameState, Player } from '../types';

interface GameStore extends GameState {
  addPlayer: (player: Player) => void;
  removePlayer: (playerId: string) => void;
  updateScore: (playerId: string, score: number) => void;
  setCurrentWord: (word: string | null) => void;
  setIsGameStarted: (started: boolean) => void;
  setTimeLeft: (time: number) => void;
  setDrawingPlayer: (playerId: string) => void;
  resetGame: () => void;
  clearPlayers: () => void;
}

const initialState: GameState = {
  players: [],
  currentWord: null,
  isGameStarted: false,
  timeLeft: 60,
};

export const useGameStore = create<GameStore>((set) => ({
  ...initialState,

  addPlayer: (player) =>
    set((state) => {
      // Remove existing player with same ID if exists
      const filteredPlayers = state.players.filter(p => p.id !== player.id);
      return { players: [...filteredPlayers, player] };
    }),

  removePlayer: (playerId) =>
    set((state) => ({
      players: state.players.filter((p) => p.id !== playerId),
    })),

  updateScore: (playerId, score) =>
    set((state) => ({
      players: state.players.map((p) =>
        p.id === playerId ? { ...p, score } : p
      ),
    })),

  setCurrentWord: (word) => set({ currentWord: word }),
  
  setIsGameStarted: (started) => set({ isGameStarted: started }),
  
  setTimeLeft: (time) => set({ timeLeft: time }),

  setDrawingPlayer: (playerId) =>
    set((state) => ({
      players: state.players.map((p) => ({
        ...p,
        isDrawing: p.id === playerId,
      })),
    })),

  clearPlayers: () => set({ players: [] }),
  
  resetGame: () => set(initialState),
}));