export interface Player {
  id: string;
  username: string;
  score: number;
  isDrawing: boolean;
}

export interface GameState {
  players: Player[];
  currentWord: string | null;
  isGameStarted: boolean;
  timeLeft: number;
}